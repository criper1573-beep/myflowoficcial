# Генерация изображений (GRS Image Web)

Веб-страница для генерации изображений через GRS AI (nano-banana) с авторизацией через Telegram. История генераций хранится по аккаунту — каждый пользователь видит только свои генерации.

## Запуск локально (без авторизации)

По умолчанию авторизация через Telegram **выключена** — страница сразу открывается, генерации сохраняются в `generated/0/`.

1. В `.env` задать минимум:
   - `GRS_AI_API_KEY` — ключ GRS AI

2. Запуск:
   ```bash
   python -m blocks.grs_image_web
   ```
   Открыть в браузере: http://127.0.0.1:8765

## Включение авторизации через Telegram (для сервера)

В `.env` задать:
- `GRS_IMAGE_WEB_REQUIRE_AUTH=true`
- `TELEGRAM_BOT_TOKEN` — токен бота
- `GRS_IMAGE_WEB_BOT_USERNAME` — имя бота без @

В [@BotFather](https://t.me/BotFather): `/setdomain` и указать домен сайта (для локальной проверки — домен туннеля ngrok/cloudflared).

## Переменные окружения

| Переменная | Описание |
|------------|----------|
| `GRS_IMAGE_WEB_REQUIRE_AUTH` | `true` — включить вход через Telegram; по умолчанию выключено (локальный режим) |
| `TELEGRAM_BOT_TOKEN` | Токен бота для верификации Telegram Login (нужен при REQUIRE_AUTH) |
| `GRS_IMAGE_WEB_BOT_USERNAME` | Имя бота без @ для виджета «Войти через Telegram» |
| `GRS_IMAGE_WEB_SESSION_SECRET` | Опционально: секрет подписи cookie (по умолчанию — токен бота) |
| `GRS_IMAGE_WEB_HOST` | Хост (по умолчанию 127.0.0.1; на сервере — 0.0.0.0) |
| `GRS_IMAGE_WEB_PORT` | Порт (по умолчанию 8765) |

См. также `docs/rules/KEYS_AND_TOKENS.md` и `docs/config/.env.example`.

## Опционально: гифка при загрузке

При генерации показывается гифка Nyan Cat. По умолчанию используется локальный файл `static/nyan.gif`. Если его нет, отображается текстовый fallback (🐱 ✨). Чтобы добавить гифку: скачайте любой Nyan Cat GIF (например, с Tenor) и сохраните как `blocks/grs_image_web/static/nyan.gif`.
